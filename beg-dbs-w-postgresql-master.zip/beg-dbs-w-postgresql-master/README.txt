
This is the source code for Beginning Databases with PostgreSQL, second deition, ISBN 1590594789.

Two folders are included; the contents are identical except that one is formatted with UNIX end of line conventions, a single LF, and the other uses the DOS/Windows convention of CRLF line terminators. Users of Linux, Mac OS X and other UNIX-like systems should use the sample programs from the UNIX folder.

For convenience, the scripts used to populate the bpsimple database in chapter 3 have also been merged into a single script, pop-all-tables.sql.

The SQL scripts for creating, populating and dropping the sample databases can be found collected together in the AppendixE folder.

The sample program from Appendix F can be found in the Chapter13 folder as it uses the same Makefile.




