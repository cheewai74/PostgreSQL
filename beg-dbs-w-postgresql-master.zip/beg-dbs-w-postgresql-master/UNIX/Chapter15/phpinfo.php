<?php 
   phpinfo(); 
?>
