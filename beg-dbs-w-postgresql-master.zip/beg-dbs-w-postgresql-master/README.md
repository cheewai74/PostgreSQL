# Apress Source Code

This repository accompanies [*Beginning Databases with PostgreSQL*](http://www.apress.com/9781590594780) by Richard Stones and Neil Matthew (Apress, 2005).

![Cover image](9781590594780.jpg)

Download the files as a zip using the green button, or clone the repository to your machine using Git.

## Releases

Release v1.0 corresponds to the code in the published book, without corrections or updates.

## Contributions

See the file Contributing.md for more information on how you can contribute to this repository.
